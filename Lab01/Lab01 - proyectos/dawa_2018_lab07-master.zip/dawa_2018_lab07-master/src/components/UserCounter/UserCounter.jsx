import React from 'react';

const userCounter = (props) => (<div>Total de usuarios: {props.counter}</div>)

export default userCounter;